﻿using SQLite.Net.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThesisMobile.DataModel
{
    [Table("Challenge")]
    public class Challenge
    {
        [PrimaryKey, NotNull]
        public int  ChallengeID { get; set; }
        public int CategoryID { get; set; }
        public string ChallengeName { get; set; }
        public string ChallengeDescription { get; set; }
        public bool IsActive { get; set; }

        [Ignore]
        public List<Exercise> ExersiceList { get; set; }


    }
}
