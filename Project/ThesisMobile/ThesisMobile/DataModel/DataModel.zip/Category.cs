﻿using SQLite.Net.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThesisMobile.DataModel
{
    [Table("Category")]
    public class Category
    {
        [PrimaryKey, NotNull]
        public int CategoryID { get; set; }
        [NotNull]
        public string CategoryName { get; set; }
        [NotNull]
        public string CategoryDescription { get; set; }

        [Ignore]
        public List<Challenge> Challenges { get; set; }
    }
}
