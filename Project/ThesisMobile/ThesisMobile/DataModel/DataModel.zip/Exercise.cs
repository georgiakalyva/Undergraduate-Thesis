﻿using SQLite.Net.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThesisMobile.DataModel
{
    [Table("Exercise")]

    public class Exercise
    {
        [PrimaryKey, NotNull]
        public int ExerciseID { get; set; }
        [NotNull]
        public string ExerciseName { get; set; }
        public string ExerciseDescription { get; set; }


    }
}
