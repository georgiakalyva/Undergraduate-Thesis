﻿using SQLite.Net.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThesisMobile.DataModel
{
    [Table("ChallengeExersiceDetails")]
    public class ChallengeExersiceDetails
    {
        [PrimaryKey, NotNull]
        public int ChallengeExersiceDetailsID { get; set; }
        [NotNull]
        public int ChallengeID { get; set; }
        [NotNull]
        public int DayID { get; set; }
        [NotNull]
        public int ExerciseID { get; set; }
        public int Timer { get; set; }
        public int Repetitions { get; set; }
        public int Circuit { get; set; }   
        public int Completed { get; set; }    
        



    }
}
